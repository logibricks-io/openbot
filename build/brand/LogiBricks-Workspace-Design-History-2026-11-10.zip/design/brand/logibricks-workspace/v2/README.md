# LogiBricks Workspace · Brand kit v2

日期：2026-11-04。延续已认可的「开放式工作台」图形，新增明暗外观、克制浮雕图标和三端应用规范。v1 保留；此目录是新的设计交付基线。

## 直接查看

- `guidelines/identity-overview.png`：明暗总览。
- `guidelines/theme-preview.html`：可离线打开，支持系统／明亮／暗黑的 Web 展示稿。
- `guidelines/brand-guide.html` / `LogiBricks-Workspace-Brand-Guidelines-v2.pdf`：完整规范。
- `brand-manifest.json`：版本、应用边界和平台参考；`SHA256SUMS.txt`：全部交付文件摘要。

## 使用选择

| 场景 | 资产 | 规则 |
|---|---|---|
| Web／桌面／手机应用内 | `exports/svg/logibricks-workspace-primary-{color,inverse}.svg` | 平面转曲字标；按应用解析后的主题选择 |
| 窄导航 | `exports/svg/logibricks-workspace-symbol-*.svg` | 标准形最小 24 px；只出现图形时提供完整无障碍名称 |
| 16 / 20 px | `exports/svg/logibricks-workspace-micro-*.svg` | 光学稿，不能从复杂立体图缩小代替 |
| 桌面启动图标 | `exports/platform/desktop/desktop-icon-{light,dark}-1024.*` | 柔和立体图；普通 Windows／Linux 首版使用 dark 固定版 |
| Windows | `exports/platform/desktop/LogiBricks-Workspace.ico` | 多尺寸，16 / 24 / 32 用清晰的平面稿；大尺寸用立体稿 |
| macOS 兼容图标 | `exports/platform/desktop/LogiBricks-Workspace.icns` | 已由 iconutil 生成；系统外观另走 `.icon`，仍需实际签名包验证 |
| macOS 菜单栏 | `exports/platform/desktop/TrayTemplate*.png` | 原生 template 处理；不拿彩色启动图标直接缩成 16 px |
| Windows 托盘 | `exports/platform/desktop/tray-*.png` | 由运行时代码按系统托盘主题选择，与应用主题分别处理 |
| Apple 原生图标 | `exports/platform/apple/` | 1024 无蒙版分层源；Icon Composer 导入后配置 Default / Dark / Clear / Tinted。PNG 是旧系统候选兼容稿，不是已编译 `.icon` |
| Android | `exports/platform/android/` | 108 dp 图层，中心 48 dp 标志。`res/` 默认深色底＋内部渐变；monochrome 由启动器着色。需原生编译验证 |
| Google Play | `exports/platform/android/google-play-512.png` | 不透明、完整方形、sRGB、512 px，禁止上传带外轮廓阴影的桌面稿 |
| 浏览器标签 | `exports/web/favicon-fallback.svg` / `favicon.ico` | 固定底色兜底；`favicon-auto.svg` 为增强项，不承诺 Safari 或所有浏览器动态切换 |
| 安装式 PWA | `exports/web/pwa-{any,maskable}-{192,512}.png` | 首版固定 dark。图标与应用主题独立，不承诺安装后实时变色 |

Web 工作区以平面 SVG 为主，保持小尺寸和高信息密度下的清晰度。登录／关于页可放一枚静态立体图标；不持续旋转、不常驻发光、不以动效表示机器人工作状态。响应式预览只验证品牌使用，不替代产品功能实现。

`exports/web/brand-tokens.json` 和 CSS 提供主题颜色。Clay `#D97757` 是 Logo 的固定强调色；小字和操作按钮另用可读性更好的 action 色。完整名称固定 **LogiBricks Workspace**，系统空间有限时使用 **LogiBricks**，不使用其他拼写。

## 可复现生成

源字体来自 Google Fonts Inter，原始 SIL OFL 文件在 `licenses/`。字标发布 SVG 已转曲；源字体只供编辑／示例页使用。

```sh
python3 source/build_v2.py --libs /path/to/isolated/python/dependencies
node source/render_v2.mjs
python3 source/package_checks.py --libs /path/to/isolated/python/dependencies
# 完成展示页与 PDF 视觉复核后冻结交付包
python3 source/freeze_package.py
```

Python 需要 fonttools、uharfbuzz、Pillow，PDF 检查另外需要 PyMuPDF；Node 需要 sharp，或通过 `BRAND_SHARP_MODULE` 指定本地安装。PDF 由 Chromium 打印 `guidelines/brand-guide.html`（CSS 页尺寸、背景开启、无页眉页脚）后检查。Web 两种模式的截图是实际预览结果；重新制作 PDF 前要刷新截图。

## 验证边界

交付中的 QA JSON 记录文件、透明度、尺寸、颜色对比和 PDF 检查；图标及示例页已进行视觉复核。它们不表示 Apple Icon Composer、Android 资源编译、安装包签名、真实设备主题切换、商标检索或产品品牌替换已经完成。

v2 是设计资产交付，不改变原项目许可证或归属。品牌替换实施已纳入 `docs/superpowers/specs/2026-11-04-logibricks-brand-integration-design.md` 和既有 GCP 部署计划的 T09B。
