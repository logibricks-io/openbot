import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
const require=createRequire(import.meta.url);
const sharp=require(process.env.BRAND_SHARP_MODULE||'sharp');
const root=path.dirname(path.dirname(fileURLToPath(import.meta.url)));
async function render(src,dest,width){await fs.mkdir(path.dirname(dest),{recursive:true});await sharp(await fs.readFile(src),{density:144}).resize({width}).ensureAlpha().withIccProfile('srgb').png().toFile(dest);}
for(const name of await fs.readdir(path.join(root,'exports/svg'))){
 if(!name.endsWith('.svg'))continue;
 const w=name.includes('micro-16')?16:name.includes('micro-20')?20:name.includes('app-icon')?1024:name.includes('symbol')?512:name.includes('stacked')?800:1400;
 await render(path.join(root,'exports/svg',name),path.join(root,'exports/png',name.replace('.svg','.png')),w);
}
await render(path.join(root,'guidelines/identity-overview.svg'),path.join(root,'guidelines/identity-overview.png'),1600);
for(const mode of ['light','dark']){
 const native=path.join(root,`exports/svg/app-icon-${mode}-1024.svg`);
 await render(native,path.join(root,`exports/platform/apple/app-icon-${mode}-1024.png`),1024);
 await render(path.join(root,`exports/platform/desktop/desktop-icon-${mode}-1024.svg`),path.join(root,`exports/platform/desktop/desktop-icon-${mode}-1024.png`),1024);
 for(const size of [32,48,64,128,256,512]) await render(path.join(root,`exports/platform/desktop/desktop-icon-${mode}-1024.svg`),path.join(root,`exports/platform/desktop/icon-${mode}-${size}.png`),size);
 for(const kind of ['foreground','background'])await render(path.join(root,`exports/platform/android/adaptive-${kind}-${mode}.svg`),path.join(root,`exports/platform/android/adaptive-${kind}-${mode}-432.png`),432);
}
await render(path.join(root,'exports/platform/android/adaptive-monochrome.svg'),path.join(root,'exports/platform/android/adaptive-monochrome-432.png'),432);
await render(path.join(root,'exports/svg/app-icon-dark-1024.svg'),path.join(root,'exports/platform/android/google-play-512.png'),512);
for(const size of [192,512])await render(path.join(root,'exports/svg/app-icon-dark-1024.svg'),path.join(root,`exports/web/pwa-maskable-${size}.png`),size);
for(const size of [192,512])await render(path.join(root,'exports/platform/desktop/desktop-icon-dark-1024.svg'),path.join(root,`exports/web/pwa-any-${size}.png`),size);
await render(path.join(root,'exports/svg/app-icon-dark-1024.svg'),path.join(root,'exports/web/apple-touch-icon-180.png'),180);
for(const size of [16,24,32,48,64,128,256])await render(path.join(root,'exports/web/favicon-fallback.svg'),path.join(root,`exports/web/favicon-${size}.png`),size);
for(const [name,v,size] of [['TrayTemplate','black',16],['TrayTemplate@2x','black',32],['tray-dark','white',16],['tray-light','black',16],['tray-dark@2x','white',32],['tray-light@2x','black',32]])
 await render(path.join(root,`exports/svg/logibricks-workspace-micro-16-${v}.svg`),path.join(root,`exports/platform/desktop/${name}.png`),size);

function roundRect(x,y,w,h,r){const k=.5522847498307936*r;return `M${x+r},${y} H${x+w-r} C${x+w-r+k},${y} ${x+w},${y+r-k} ${x+w},${y+r} V${y+h-r} C${x+w},${y+h-r+k} ${x+w-r+k},${y+h} ${x+w-r},${y+h} H${x+r} C${x+r-k},${y+h} ${x},${y+h-r+k} ${x},${y+h-r} V${y+r} C${x},${y+r-k} ${x+r-k},${y} ${x+r},${y} Z`;}
const rects=[[0,0,24,48],[0,56,48,24],[56,56,24,24],[56,0,24,24]];
// Native adaptive vector shading is contained inside the canonical silhouette.
for(const mono of [false,true]){
 let paths=rects.map(([x,y,w,h],i)=>{
  const d=roundRect(30+x*.6,30+y*.6,w*.6,h*.6,2.4);
  if(mono)return `<path android:fillColor="#FFFFFFFF" android:pathData="${d}"/>`;
  const stops=i===3?['#FFF1A084','#FFC26446']:['#FFFFFFFF','#FFD7D4CD'];
  return `<path android:pathData="${d}"><aapt:attr name="android:fillColor"><gradient android:type="linear" android:startX="${30+x*.6}" android:startY="${30+y*.6}" android:endX="${30+(x+w)*.6}" android:endY="${30+(y+h)*.6}"><item android:offset="0" android:color="${stops[0]}"/><item android:offset="1" android:color="${stops[1]}"/></gradient></aapt:attr></path>`;
 }).join('\n');
 const dest=path.join(root,`exports/platform/android/res/drawable/logibricks_workspace_${mono?'monochrome':'foreground'}.xml`);await fs.mkdir(path.dirname(dest),{recursive:true});
 await fs.writeFile(dest,`<?xml version="1.0" encoding="utf-8"?>\n<vector xmlns:android="http://schemas.android.com/apk/res/android" xmlns:aapt="http://schemas.android.com/aapt" android:width="108dp" android:height="108dp" android:viewportWidth="108" android:viewportHeight="108">${paths}</vector>`);
}
for(const api of ['v26','v33']){
 const dir=path.join(root,`exports/platform/android/res/mipmap-anydpi-${api}`);await fs.mkdir(dir,{recursive:true});
 const xml=`<?xml version="1.0" encoding="utf-8"?>\n<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android"><background android:drawable="@color/logibricks_workspace_icon_background"/><foreground android:drawable="@drawable/logibricks_workspace_foreground"/>${api==='v33'?'<monochrome android:drawable="@drawable/logibricks_workspace_monochrome"/>':''}</adaptive-icon>`;
 for(const n of ['ic_launcher.xml','ic_launcher_round.xml'])await fs.writeFile(path.join(dir,n),xml);
}
await fs.mkdir(path.join(root,'exports/platform/android/res/values'),{recursive:true});
await fs.writeFile(path.join(root,'exports/platform/android/res/values/logibricks_workspace_colors.xml'),'<resources><color name="logibricks_workspace_icon_background">#18181B</color></resources>');
const meta=await sharp(path.join(root,'exports/platform/android/google-play-512.png')).metadata();
console.log(JSON.stringify({rendered:true,sharp:sharp.versions.sharp,play:{width:meta.width,height:meta.height,channels:meta.channels,space:meta.space,hasProfile:meta.hasProfile}}));
