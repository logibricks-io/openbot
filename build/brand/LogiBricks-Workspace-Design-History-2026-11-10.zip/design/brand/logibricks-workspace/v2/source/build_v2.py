"""Build v2 native-vector brand assets. Requires fonttools and uharfbuzz.

Run with --libs <isolated Python dependencies> when needed.
Canonical outlined wordmarks are retained byte-for-byte from v1.
"""
from pathlib import Path
import json
from identity_geometry import ROOT, mark, placed_mark, outline, svg, save, primary

RECTS = [(0,0,24,48),(0,56,48,24),(56,56,24,24),(56,0,24,24)]
COLORS = {
    'light': {'canvas':'#F6F3ED','surface':'#FFFFFF','ink':'#18181B','secondary':'#696A70','line':'#D9D4CB','accent':'#D97757','action':'#A2462A','onAction':'#FFFFFF'},
    'dark': {'canvas':'#151618','surface':'#202124','ink':'#F6F3ED','secondary':'#B5B3AE','line':'#414246','accent':'#D97757','action':'#F0A182','onAction':'#18181B'}
}

def icon(mode, desktop=False):
    dark=mode=='dark'; p=mode+('d' if desktop else 'n')
    bg=['#393A3D','#17181A'] if dark else ['#FFFDF8','#DED8CD']
    fg=['#FFFFFF','#D7D4CD'] if dark else ['#47484B','#17181B']
    side='#A7A49D' if dark else '#08090A'
    b,sz,r=(64,896,192) if desktop else (0,1024,0)
    defs=f'''<defs>
      <linearGradient id="{p}bg" x1="0" y1="0" x2=".8" y2="1"><stop stop-color="{bg[0]}"/><stop offset="1" stop-color="{bg[1]}"/></linearGradient>
      <linearGradient id="{p}fg" x2=".35" y2="1"><stop stop-color="{fg[0]}"/><stop offset="1" stop-color="{fg[1]}"/></linearGradient>
      <linearGradient id="{p}clay" x2=".3" y2="1"><stop stop-color="#F1A084"/><stop offset=".38" stop-color="#DF8262"/><stop offset="1" stop-color="#C26446"/></linearGradient>
      <linearGradient id="{p}rim" x2=".8" y2="1"><stop stop-color="#FFFFFF" stop-opacity="{'.24' if dark else '.8'}"/><stop offset=".5" stop-color="#FFFFFF" stop-opacity=".04"/><stop offset="1" stop-color="#000000" stop-opacity=".16"/></linearGradient>
      <filter id="{p}tile" x="-20%" y="-20%" width="140%" height="150%"><feDropShadow dx="0" dy="22" stdDeviation="18" flood-color="#080A0B" flood-opacity=".22"/></filter>
      <filter id="{p}lift" x="-30%" y="-30%" width="160%" height="180%"><feDropShadow dx="0" dy="1.5" stdDeviation="1.1" flood-color="#000000" flood-opacity="{'.38' if dark else '.25'}"/></filter>
    </defs>'''
    tile=f'<rect x="{b}" y="{b}" width="{sz}" height="{sz}" rx="{r}" fill="url(#{p}bg)"'+(f' filter="url(#{p}tile)"' if desktop else '')+'/>'
    if desktop:tile+=f'<rect x="{b+2}" y="{b+2}" width="{sz-4}" height="{sz-4}" rx="{r-2}" fill="none" stroke="url(#{p}rim)" stroke-width="4"/>'
    pieces=''
    for i,(x,y,w,h) in enumerate(RECTS):
        base='#A95239' if i==3 else side
        pieces+=f'<g filter="url(#{p}lift)"><rect x="{x}" y="{y+1.05}" width="{w}" height="{h}" rx="4" fill="{base}"/><rect x="{x}" y="{y}" width="{w}" height="{h}" rx="4" fill="url(#{p}{"clay" if i==3 else "fg"})"/><rect x="{x+.15}" y="{y+.15}" width="{w-.3}" height="{h-.3}" rx="3.85" fill="none" stroke="#FFFFFF" stroke-opacity="{'.35' if dark or i==3 else '.14'}" stroke-width=".3"/></g>'
    return defs+tile+f'<g transform="translate(224 220) scale(7.2)">{pieces}</g>'

for mode in COLORS:
    save(f'app-icon-{mode}-1024.svg',icon(mode),1024,1024)
    save(f'desktop-icon-{mode}-1024.svg',icon(mode,True),1024,1024,'exports/platform/desktop')
    c=COLORS[mode]
    save(f'background-{mode}.svg',f'<rect width="1024" height="1024" fill="{c["canvas"]}"/>',1024,1024,'exports/platform/apple')
    framework=''.join(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="4" fill="{c["ink"]}"/>' for x,y,w,h in RECTS[:3])
    save(f'framework-{mode}.svg',f'<g transform="translate(224 224) scale(7.2)">{framework}</g>',1024,1024,'exports/platform/apple')
    save(f'active-module-{mode}.svg','<g transform="translate(224 224) scale(7.2)"><rect x="56" y="0" width="24" height="24" rx="4" fill="#D97757"/></g>',1024,1024,'exports/platform/apple')
save('framework-monochrome.svg',placed_mark(224,224,576,'#FFFFFF','#FFFFFF'),1024,1024,'exports/platform/apple')

# Platform masks and lighting belong to Icon Composer, not these flat layer sources.
for mode in COLORS:
    c=COLORS[mode]
    stops=['#FFFFFF','#D7D4CD'] if mode=='dark' else ['#47484B','#17181B']
    definitions=f'<defs><linearGradient id="fg" x2="1" y2="1"><stop stop-color="{stops[0]}"/><stop offset="1" stop-color="{stops[1]}"/></linearGradient><linearGradient id="clay" x2="1" y2="1"><stop stop-color="#F1A084"/><stop offset="1" stop-color="#C26446"/></linearGradient></defs>'
    save(f'adaptive-foreground-{mode}.svg',definitions+placed_mark(30,30,48,'url(#fg)','url(#clay)'),108,108,'exports/platform/android')
    save(f'adaptive-background-{mode}.svg',f'<rect width="108" height="108" fill="{c["canvas"]}"/>',108,108,'exports/platform/android')
save('adaptive-monochrome.svg',placed_mark(30,30,48,'#FFFFFF','#FFFFFF'),108,108,'exports/platform/android')

# Favicons follow browser/system preference; app Logo uses the resolved application theme.
micro=(ROOT/'exports/svg/logibricks-workspace-micro-16-color.svg').read_text()
for mode in COLORS:
    c=COLORS[mode]
    body=''.join(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="1" fill="{c["accent"] if i==3 else c["ink"]}"/>' for i,(x,y,w,h) in enumerate([(2,2,4,7),(2,10,7,4),(10,10,4,4),(10,2,4,4)]))
    save(f'favicon-{mode}.svg',body,16,16,'exports/web')
auto='<style>.frame{fill:#18181B}.active{fill:#D97757}@media(prefers-color-scheme:dark){.frame{fill:#F6F3ED}}</style>'
auto+=''.join(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="1" class="{"active" if i==3 else "frame"}"/>' for i,(x,y,w,h) in enumerate([(2,2,4,7),(2,10,7,4),(10,10,4,4),(10,2,4,4)]))
save('favicon-auto.svg',auto,16,16,'exports/web')
save('favicon-fallback.svg','<rect width="16" height="16" rx="3" fill="#18181B"/>'+auto.split('</style>')[1].replace('class="frame"','fill="#F6F3ED"').replace('class="active"','fill="#D97757"'),16,16,'exports/web')

tokens={'brand':{'name':'LogiBricks Workspace','compactName':'LogiBricks','assetVersion':'2.0.0'},'themes':COLORS,'themePreference':['system','light','dark'],'defaultTheme':'system','iconAppearanceIndependent':True,'geometry':{'viewBox':80,'clearSpace':24,'standardMinimumPx':24,'opticalSizes':[16,20]}}
(ROOT/'exports/web/brand-tokens.json').write_text(json.dumps(tokens,ensure_ascii=False,indent=2))
css=':root{color-scheme:light dark}\n'
for mode,c in COLORS.items():css+=f'[data-theme="{mode}"]'+'{'+f'color-scheme:{mode};'+''.join(f'--brand-{k}:{v};' for k,v in c.items())+'}\n'
css+='@media(forced-colors:active){.brand-symbol{color:CanvasText}.brand-symbol *{fill:currentColor!important}}\n'
(ROOT/'exports/web/brand-tokens.css').write_text(css)

def text(t,sz,x,y,weight=500,color='#18181B',tracking=0):return outline(t,sz,x,y,weight,color,tracking)[0]
def embed(body,x,y,size):return f'<svg x="{x}" y="{y}" width="{size}" height="{size}" viewBox="0 0 1024 1024">{body}</svg>'
board='<rect width="1600" height="1120" fill="#F6F3ED"/>'
board+=text('LogiBricks Workspace',40,64,88,650,tracking=-.9)
board+=text('One identity. Every environment.',22,65,130,450,'#696A70')
board+=text('V2 / 04 NOV 2026',13,1370,85,500,'#696A70')
board+='<rect x="800" y="184" width="800" height="936" fill="#151618"/>'
for i,mode in enumerate(COLORS):
    x=i*800;c=COLORS[mode]
    board+=text('Light' if mode=='light' else 'Dark',28,x+64,246,600,c['ink'],-.4)
    board+=text('Ceramic & graphite' if mode=='light' else 'Graphite & warm porcelain',16,x+64,277,450,c['secondary'])
    board+=embed(icon(mode,True),x+196,301,408)
    board+=text('Dimensional app icon',17,x+64,765,550,c['ink'])
    board+=text('Soft relief. Clear silhouette.',15,x+64,794,450,c['secondary'])
    board+=f'<path d="M{x+64} 832 H{x+736}" stroke="{c["line"]}"/>'
    body,w,h=primary(c['ink'],c['accent'],c['secondary'])
    board+=f'<svg x="{x+64}" y="881" width="255" height="64" viewBox="0 0 {w} {h}">{body}</svg>'
    board+=text('Flat identity for the Web',17,x+390,908,550,c['ink'])
    board+=text('Navigation / login / workspace',14,x+390,937,450,c['secondary'])
    for j,n in enumerate([16,20,24,32]):board+=placed_mark(x+67+j*64,1012,n,c['ink'],c['accent']) if n>=24 else f'<g transform="translate({x+67+j*64} 1012)">'+''.join(f'<rect x="{xx}" y="{yy}" width="{ww}" height="{hh}" rx="1" fill="{c["accent"] if k==3 else c["ink"]}"/>' for k,(xx,yy,ww,hh) in enumerate([(2,2,4,7),(2,10,7,4),(10,10,4,4),(10,2,4,4)] if n==16 else [(2,2,5,9),(2,13,9,5),(13,13,5,5),(13,2,5,5)]))+'</g>'
    board+=text('Optical masters at 16 / 20 px',14,x+390,1034,450,c['secondary'])
save('identity-overview.svg',board,1600,1120,'guidelines')

meta={'name':'LogiBricks Workspace','version':'2.0.0','date':'2026-11-04','concept':'Open Workbench','baseIdentity':'v1 approved direction; canonical mark and outlined wordmarks unchanged','themes':COLORS,'appIcon':'Subtle dimensional relief, light and dark; OS mask handled per platform','web':'Flat SVG navigation; optional static dimensional icon on login/about','source':'Editable vectors, Inter outlined wordmark; original OFL font and license retained','status':{'assets':'authored; see qa for checks','productionIntegration':'not performed','appleIconComposer':'layer sources prepared; .icon compilation and device review pending','android':'adaptive sources prepared; native compilation and device review pending','windowsMacLinux':'resource sources prepared; signed package validation pending','trademarkClearance':'not performed'},'platformDocs':[
'https://developer.apple.com/design/human-interface-guidelines/app-icons/',
'https://developer.apple.com/documentation/Xcode/creating-your-app-icon-using-icon-composer',
'https://developer.android.com/develop/ui/compose/system/icon_design_adaptive',
'https://developer.android.com/distribute/google-play/resources/icon-design-specifications']}
(ROOT/'brand-manifest.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2))
print(json.dumps({'version':'2.0.0','svg':len(list(ROOT.rglob('*.svg')))}))
