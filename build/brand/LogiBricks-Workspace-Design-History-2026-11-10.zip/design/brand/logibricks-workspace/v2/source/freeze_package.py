"""Freeze authored v2 assets, checksums and a portable ZIP after visual QA."""
from pathlib import Path
import hashlib, json, zipfile
ROOT=Path(__file__).resolve().parent.parent

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def included(p):
    r=p.relative_to(ROOT)
    return p.is_file() and '__pycache__' not in r.parts and p.name!='.DS_Store' and not (r.parts[0]=='qa' and p.suffix!='.json')

inventory=[]
for p in sorted((ROOT/'exports').rglob('*')):
    if not p.is_file():continue
    rel=p.relative_to(ROOT).as_posix()
    inventory.append({'path':rel,'bytes':p.stat().st_size,'sha256':digest(p),'appearance':'dark' if 'dark' in p.name or 'inverse' in p.name else 'light' if 'light' in p.name or '-color.' in p.name else 'shared','surface':'/'.join(p.relative_to(ROOT/'exports').parts[:-1])})
(ROOT/'asset-inventory.json').write_text(json.dumps({'brandAssetVersion':'2.0.0','entries':inventory},ensure_ascii=False,indent=2))
meta=json.loads((ROOT/'brand-manifest.json').read_text())
meta.update({'inventory':'asset-inventory.json','checksums':'SHA256SUMS.txt','assetInventorySha256':digest(ROOT/'asset-inventory.json'),'verification':{'assetReport':'qa/asset-checks.json','pdfReport':'qa/pdf-checks.json','previewReport':'qa/preview-checks.json','designReview':'independent visual and plan review complete; native product integration pending'}})
(ROOT/'brand-manifest.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2))
files=sorted(p for p in ROOT.rglob('*') if included(p) and p.name!='SHA256SUMS.txt')
(ROOT/'SHA256SUMS.txt').write_text(''.join(f'{digest(p)}  {p.relative_to(ROOT).as_posix()}\n' for p in files))
dest=ROOT.parent/'LogiBricks-Workspace-Brand-Kit-v2.zip'
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(p for p in ROOT.rglob('*') if included(p)):
        info=zipfile.ZipInfo('LogiBricks-Workspace-v2/'+p.relative_to(ROOT).as_posix(),date_time=(2026,11,4,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o644<<16;z.writestr(info,p.read_bytes())
with zipfile.ZipFile(dest) as z:
    assert z.testzip() is None
    for line in (ROOT/'SHA256SUMS.txt').read_text().splitlines():
        sha,rel=line.split('  ',1);assert hashlib.sha256(z.read('LogiBricks-Workspace-v2/'+rel)).hexdigest()==sha
    count=len(z.namelist())
print(json.dumps({'zip':str(dest),'bytes':dest.stat().st_size,'files':count,'exportAssets':len(inventory),'sha256':digest(dest)}))
