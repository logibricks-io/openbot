"""Build editable geometric identity assets and outlined wordmarks.

Requires fonttools and uharfbuzz. Pass --libs for an isolated dependency directory.
Raster exports are rendered separately from these SVG sources.
"""
from pathlib import Path
import sys, json, math, hashlib, html

if '--libs' in sys.argv:
    sys.path.insert(0, sys.argv[sys.argv.index('--libs') + 1])
from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont
from fontTools.pens.svgPathPen import SVGPathPen
import uharfbuzz as hb

ROOT = Path(__file__).resolve().parent.parent
INK, CLAY, PAPER, MUTED = '#18181B', '#D97757', '#F6F3ED', '#696A70'
FONT = ROOT / 'source/Inter-variable.ttf'
data = FONT.read_bytes()
face = hb.Face(data)
font_cache = {}

def outline(text, size, x=0, y=0, weight=600, fill=INK, tracking=0):
    key = (weight, 32)
    if key not in font_cache:
        font_cache[key] = instantiateVariableFont(TTFont(FONT), {'wght':weight,'opsz':32}, inplace=False)
    tt = font_cache[key]
    glyphs = tt.getGlyphSet()
    order = tt.getGlyphOrder()
    f = hb.Font(face)
    f.scale = (face.upem, face.upem)
    f.set_variations({'wght':weight,'opsz':32})
    buf = hb.Buffer(); buf.add_str(text); buf.guess_segment_properties()
    hb.shape(f, buf, {'kern':True,'liga':True})
    scale = size / face.upem
    paths, cursor = [], 0
    for info, pos in zip(buf.glyph_infos, buf.glyph_positions):
        pen = SVGPathPen(glyphs); glyphs[order[info.codepoint]].draw(pen)
        d = pen.getCommands()
        if d:
            paths.append(f'<path d="{d}" transform="translate({x+cursor+pos.x_offset*scale:.5f} {y-pos.y_offset*scale:.5f}) scale({scale:.7f} {-scale:.7f})"/>')
        cursor += pos.x_advance * scale + tracking
    return f'<g fill="{fill}" aria-label="{html.escape(text)}">'+''.join(paths)+'</g>', max(0,cursor-tracking)

def mark(ink=INK, accent=CLAY):
    return ''.join(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="4" fill="{c}"/>'
                   for x,y,w,h,c in [(0,0,24,48,ink),(0,56,48,24,ink),(56,56,24,24,ink),(56,0,24,24,accent)])

def placed_mark(x,y,size,ink=INK,accent=CLAY):
    return f'<g transform="translate({x} {y}) scale({size/80})">{mark(ink,accent)}</g>'

def svg(body,w,h,title='LogiBricks Workspace'):
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}" role="img" aria-label="{html.escape(title)}"><title>{html.escape(title)}</title>{body}</svg>'

def save(name,body,w,h,folder='exports/svg'):
    p=ROOT/folder/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(svg(body,w,h),encoding='utf-8')

def primary(ink=INK,accent=CLAY,descriptor=MUTED):
    a,aw=outline('LogiBricks',44,112,40,650,ink,-0.9)
    b,_=outline('Workspace',20,113,72,450,descriptor,0.7)
    return mark(ink,accent)+a+b, math.ceil(112+aw+2),80

