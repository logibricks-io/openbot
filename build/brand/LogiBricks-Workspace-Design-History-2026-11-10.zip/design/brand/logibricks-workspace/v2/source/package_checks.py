"""Create ICO/ICNS compatibility files and verify the authored assets.

Requires Pillow; PyMuPDF additionally renders the PDF for visual review.
Does not build the product, Android resources or Apple Icon Composer assets.
"""
from pathlib import Path
import sys, json, struct, subprocess, shutil, xml.etree.ElementTree as ET, math, hashlib
if '--libs' in sys.argv:sys.path.insert(0,sys.argv[sys.argv.index('--libs')+1])
from PIL import Image
ROOT=Path(__file__).resolve().parent.parent

def ico(dest,frames):
    offset=6+16*len(frames); entries=[];data=[]
    for size,file in frames:
        b=file.read_bytes();entries.append(struct.pack('<BBBBHHII',0 if size==256 else size,0 if size==256 else size,0,0,1,32,len(b),offset));data.append(b);offset+=len(b)
    dest.write_bytes(struct.pack('<HHH',0,1,len(frames))+b''.join(entries)+b''.join(data))

ico(ROOT/'exports/web/favicon.ico',[(n,ROOT/f'exports/web/favicon-{n}.png') for n in [16,24,32,48,64,128,256]])
ico(ROOT/'exports/platform/desktop/LogiBricks-Workspace.ico',[(n,ROOT/(f'exports/web/favicon-{n}.png' if n<=32 else f'exports/platform/desktop/icon-dark-{n}.png')) for n in [16,24,32,48,64,128,256]])

# macOS compatibility output; current system appearance source remains .icon layers.
icns_created=False
if shutil.which('iconutil'):
    iconset=ROOT/'qa/LogiBricks-Workspace.iconset';iconset.mkdir(exist_ok=True)
    base=Image.open(ROOT/'exports/platform/desktop/desktop-icon-dark-1024.png')
    for n in [16,32,128,256,512]:
        for scale in [1,2]:
            size=n*scale
            if size<=32:im=Image.open(ROOT/f'exports/web/favicon-{size}.png')
            else:im=base.resize((size,size),Image.Resampling.LANCZOS)
            im.save(iconset/f'icon_{n}x{n}{"@2x" if scale==2 else ""}.png')
    subprocess.run(['iconutil','-c','icns',str(iconset),'-o',str(ROOT/'exports/platform/desktop/LogiBricks-Workspace.icns')],check=True)
    icns_created=True

def lum(h):
    v=[int(h[i:i+2],16)/255 for i in (1,3,5)];v=[x/12.92 if x<=.04045 else ((x+.055)/1.055)**2.4 for x in v]
    return sum(x*y for x,y in zip(v,[.2126,.7152,.0722]))
def contrast(a,b):
    x,y=sorted([lum(a),lum(b)]);return (y+.05)/(x+.05)

tokens=json.loads((ROOT/'exports/web/brand-tokens.json').read_text());checks=[]
for name,c in tokens['themes'].items():
    for foreground in ['ink','secondary','action']:
        for background in ['canvas','surface']:
            ratio=contrast(c[foreground],c[background]);assert ratio>=4.5,(name,foreground,background,ratio)
            checks.append({'theme':name,'pair':f'{foreground}/{background}','ratio':round(ratio,2)})
    ratio=contrast(c['onAction'],c['action']);assert ratio>=4.5;checks.append({'theme':name,'pair':'onAction/action','ratio':round(ratio,2)})

for p in (ROOT/'exports').rglob('*.svg'):ET.parse(p)
for p in (ROOT/'exports').rglob('*.xml'):ET.parse(p)
baseline=json.loads((ROOT/'source/canonical-v1-sha256.json').read_text())
for p in (ROOT/'exports/svg').glob('logibricks*.svg'):
    tree=ET.parse(p)
    assert not any(n.tag.rsplit('}',1)[-1] in ['text','script','image','foreignObject'] for n in tree.iter()),p.name
    assert hashlib.sha256(p.read_bytes()).hexdigest()==baseline[p.name],('v1 geometry changed',p.name)

pngs=list((ROOT/'exports').rglob('*.png'))
for p in pngs:
    with Image.open(p) as im:im.verify()
play=ROOT/'exports/platform/android/google-play-512.png'
with Image.open(play) as im:
    assert im.size==(512,512) and im.mode=='RGBA' and im.getchannel('A').getextrema()==(255,255)
    assert im.info.get('icc_profile')
assert play.stat().st_size<=1024*1024
for n in [192,512]:
    with Image.open(ROOT/f'exports/web/pwa-maskable-{n}.png') as im:assert im.getchannel('A').getextrema()==(255,255)
with Image.open(ROOT/'exports/platform/desktop/LogiBricks-Workspace.ico') as im:ico_sizes=sorted(im.ico.sizes());assert len(ico_sizes)==7

# Sample essential rounded-rectangle outlines against centered safe circles.
def radius(rects,offset,scale,center):
    largest=0
    for x,y,w,h in rects:
        for cx,cy,start in [(x+4,y+4,180),(x+w-4,y+4,270),(x+w-4,y+h-4,0),(x+4,y+h-4,90)]:
            for deg in range(start,start+91):
                px=offset+(cx+4*math.cos(math.radians(deg)))*scale
                py=offset+(cy+4*math.sin(math.radians(deg)))*scale
                largest=max(largest,math.hypot(px-center,py-center))
    return largest
rects=[(0,0,24,48),(0,56,48,24),(56,56,24,24),(56,0,24,24)]
adaptive=radius(rects,30,.6,54);assert adaptive<=33
maskable=radius(rects,224,7.2,512);assert maskable+12<409.6

report={'svgParsed':len(list((ROOT/'exports').rglob('*.svg'))),'pngVerified':len(pngs),'canonicalV1MastersUnchanged':True,'playBytes':play.stat().st_size,'playOpaqueSrgb':True,'icoSizes':ico_sizes,'icnsGeneratedByIconutil':icns_created,'contrast':checks,'adaptiveEssentialRadiusDp':adaptive,'adaptiveSafeRadiusDp':33,'maskableEssentialPlusReliefBoundPx':maskable+12,'maskableSafeRadiusPx':409.6,'runtimeLimit':'No product/native compilation, signing or physical device validation'}
(ROOT/'qa/asset-checks.json').write_text(json.dumps(report,indent=2))

pdf=ROOT/'guidelines/LogiBricks-Workspace-Brand-Guidelines-v2.pdf'
if pdf.exists():
    import pymupdf as fitz
    doc=fitz.open(pdf);assert len(doc)==6
    pages=[];thumbs=[]
    for i,page in enumerate(doc):
        png=ROOT/f'qa/pdf-page-{i+1}.png';page.get_pixmap(matrix=fitz.Matrix(1.5,1.5)).save(png)
        pages.append({'page':i+1,'widthPt':page.rect.width,'heightPt':page.rect.height,'textChars':len(page.get_text())})
        assert i==0 or len(page.get_text())>200
        im=Image.open(png).convert('RGB');im.thumbnail((560,397));thumbs.append(im.copy())
    sheet=Image.new('RGB',(1144,3*421+24),'#DCD6CD')
    for i,im in enumerate(thumbs):sheet.paste(im,(12+(i%2)*572,12+(i//2)*421))
    sheet.save(ROOT/'qa/pdf-contact-sheet.png')
    (ROOT/'qa/pdf-checks.json').write_text(json.dumps({'pages':pages,'coverTextOutlined':True,'visualReview':'See rendered pages; requires human/agent inspection, not text extraction only'},indent=2))
print(json.dumps(report))
