# LogiBricks Workspace 平台导出说明

v2 是几何和配色基线。通用桌面 PNG 不再直接用于 macOS Dock。macOS 的开发版 PNG 与旧系统 ICNS 使用独立校准导出：1024 画布、居中 824 px 可见底板；896 px 通用底板只缩放一次，保留拟物材质。824 是在本机对系统应用渲染结果的实测，不是 Apple 要求所有源图层必须内缩的数值。正式 macOS 使用系统图标目录及完整未预裁切的 Icon Composer 源；仅开发版的 Electron 宿主需覆盖 Dock 图标。

- macOS PNG：[开发版 Dock](../../../build/icon-dev-macos-safe-area.png)；旧系统：[ICNS](../../../build/icon-production.icns)。
- 分层源：[icon.json](../../../build/icon-production.icon/icon.json)；重新生成：[导出脚本](../../../scripts/generate-macos-raster-icons.ts)。
- 设置等紧凑行：16 CSS px 使用 v2 的 micro-16 光学稿；名称跟随同组设置值的字号、行高及颜色。
- 平台依据：[Apple App icons](https://developer.apple.com/design/human-interface-guidelines/app-icons/)。原 v2 ZIP 保留为历史版本；本补充覆盖其 macOS 扁平图标的使用说明。
