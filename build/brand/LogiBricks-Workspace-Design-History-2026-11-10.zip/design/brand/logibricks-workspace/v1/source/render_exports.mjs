import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const sharp = require(process.env.BRAND_SHARP_MODULE || 'sharp');
const root = path.dirname(path.dirname(fileURLToPath(import.meta.url)));

async function render(src, dest, width) {
  await fs.mkdir(path.dirname(dest), {recursive:true});
  await sharp(await fs.readFile(src), {density:144}).resize({width}).ensureAlpha().withIccProfile('srgb').png().toFile(dest);
}
const svgDir=path.join(root,'exports/svg');
for(const file of await fs.readdir(svgDir)) {
  if(!file.endsWith('.svg')) continue;
  const base=file.slice(0,-4);
  const size=base.includes('micro-16')?16:base.includes('micro-20')?20:base.includes('app-icon')?1024:base.includes('symbol')?512:base.includes('stacked')?800:1400;
  await render(path.join(svgDir,file),path.join(root,'exports/png',base+'.png'),size);
}
for(const [name,w] of [['identity-overview',1600],['workspace-application',1440]])
  await render(path.join(root,'guidelines',name+'.svg'),path.join(root,'guidelines',name+'.png'),w);

for(const size of [16,20,24,32,48,64,128,256]) {
  const micro=size===16||size===20;
  for(const variant of ['color','inverse','black','white']) {
    const src=micro?`logibricks-workspace-micro-${size}-${variant}.svg`:`logibricks-workspace-symbol-${variant}.svg`;
    await render(path.join(svgDir,src),path.join(root,'qa',`symbol-${size}-${variant}.png`),size);
  }
}
await render(path.join(svgDir,'app-icon-dark-1024.svg'),path.join(root,'exports/platform/android','google-play-512.png'),512);
await render(path.join(svgDir,'app-icon-dark-1024.svg'),path.join(root,'exports/platform/apple','app-icon-dark-1024.png'),1024);
await render(path.join(svgDir,'app-icon-light-1024.svg'),path.join(root,'exports/platform/apple','app-icon-light-1024.png'),1024);
for(const layer of ['adaptive-foreground','adaptive-monochrome','adaptive-background'])
  await render(path.join(root,'exports/platform/android',layer+'.svg'),path.join(root,'exports/platform/android',layer+'-432.png'),432);

function roundRect(x,y,w,h,r){const k=.5522847498307936*r;return `M${x+r},${y} H${x+w-r} C${x+w-r+k},${y} ${x+w},${y+r-k} ${x+w},${y+r} V${y+h-r} C${x+w},${y+h-r+k} ${x+w-r+k},${y+h} ${x+w-r},${y+h} H${x+r} C${x+r-k},${y+h} ${x},${y+h-r+k} ${x},${y+h-r} V${y+r} C${x},${y+r-k} ${x+r-k},${y} ${x+r},${y} Z`;}
const rects=[[0,0,24,48],[0,56,48,24],[56,56,24,24],[56,0,24,24]];
for(const mono of [false,true]){
  const paths=rects.map(([x,y,w,h],i)=>`  <path android:fillColor="${mono?'#FFFFFFFF':i===3?'#FFD97757':'#FFF6F3ED'}" android:pathData="${roundRect(30+x*.6,30+y*.6,w*.6,h*.6,2.4)}"/>`).join('\n');
  const file=path.join(root,'exports/platform/android/res/drawable',mono?'logibricks_workspace_monochrome.xml':'logibricks_workspace_foreground.xml');
  await fs.mkdir(path.dirname(file),{recursive:true});
  await fs.writeFile(file,`<?xml version="1.0" encoding="utf-8"?>\n<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="108dp" android:height="108dp" android:viewportWidth="108" android:viewportHeight="108">\n${paths}\n</vector>\n`);
}
for(const api of ['v26','v33']){
  const dir=path.join(root,`exports/platform/android/res/mipmap-anydpi-${api}`);await fs.mkdir(dir,{recursive:true});
  const xml=`<?xml version="1.0" encoding="utf-8"?>\n<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n  <background android:drawable="@color/logibricks_workspace_icon_background"/>\n  <foreground android:drawable="@drawable/logibricks_workspace_foreground"/>${api==='v33'?'\n  <monochrome android:drawable="@drawable/logibricks_workspace_monochrome"/>':''}\n</adaptive-icon>\n`;
  for(const n of ['ic_launcher.xml','ic_launcher_round.xml'])await fs.writeFile(path.join(dir,n),xml);
}
const colors=path.join(root,'exports/platform/android/res/values');await fs.mkdir(colors,{recursive:true});
await fs.writeFile(path.join(colors,'logibricks_workspace_colors.xml'),'<?xml version="1.0" encoding="utf-8"?>\n<resources><color name="logibricks_workspace_icon_background">#18181B</color></resources>\n');
const micro=await fs.readFile(path.join(svgDir,'logibricks-workspace-micro-16-inverse.svg'),'utf8');
const favicon=micro.replace('</title>','</title><rect width="16" height="16" fill="#18181B"/>');
await fs.writeFile(path.join(svgDir,'favicon.svg'),favicon);
for(const size of [16,32,48,64,128,256])await render(path.join(svgDir,'favicon.svg'),path.join(root,'exports/png',`favicon-${size}.png`),size);
const meta=await sharp(path.join(root,'exports/platform/android/google-play-512.png')).metadata();
console.log(JSON.stringify({rendered:true,sharp:sharp.versions.sharp,play:{width:meta.width,height:meta.height,channels:meta.channels,space:meta.space,hasProfile:meta.hasProfile}}));
