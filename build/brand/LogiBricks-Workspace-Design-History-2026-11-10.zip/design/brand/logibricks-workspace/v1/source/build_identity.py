"""Build editable geometric identity assets and outlined wordmarks.

Requires fonttools and uharfbuzz. Pass --libs for an isolated dependency directory.
Raster exports are rendered separately from these SVG sources.
"""
from pathlib import Path
import sys, json, math, hashlib, html

if '--libs' in sys.argv:
    sys.path.insert(0, sys.argv[sys.argv.index('--libs') + 1])
from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont
from fontTools.pens.svgPathPen import SVGPathPen
import uharfbuzz as hb

ROOT = Path(__file__).resolve().parent.parent
INK, CLAY, PAPER, MUTED = '#18181B', '#D97757', '#F6F3ED', '#696A70'
FONT = ROOT / 'source/Inter-variable.ttf'
data = FONT.read_bytes()
face = hb.Face(data)
font_cache = {}

def outline(text, size, x=0, y=0, weight=600, fill=INK, tracking=0):
    key = (weight, 32)
    if key not in font_cache:
        font_cache[key] = instantiateVariableFont(TTFont(FONT), {'wght':weight,'opsz':32}, inplace=False)
    tt = font_cache[key]
    glyphs = tt.getGlyphSet()
    order = tt.getGlyphOrder()
    f = hb.Font(face)
    f.scale = (face.upem, face.upem)
    f.set_variations({'wght':weight,'opsz':32})
    buf = hb.Buffer(); buf.add_str(text); buf.guess_segment_properties()
    hb.shape(f, buf, {'kern':True,'liga':True})
    scale = size / face.upem
    paths, cursor = [], 0
    for info, pos in zip(buf.glyph_infos, buf.glyph_positions):
        pen = SVGPathPen(glyphs); glyphs[order[info.codepoint]].draw(pen)
        d = pen.getCommands()
        if d:
            paths.append(f'<path d="{d}" transform="translate({x+cursor+pos.x_offset*scale:.5f} {y-pos.y_offset*scale:.5f}) scale({scale:.7f} {-scale:.7f})"/>')
        cursor += pos.x_advance * scale + tracking
    return f'<g fill="{fill}" aria-label="{html.escape(text)}">'+''.join(paths)+'</g>', max(0,cursor-tracking)

def mark(ink=INK, accent=CLAY):
    return ''.join(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="4" fill="{c}"/>'
                   for x,y,w,h,c in [(0,0,24,48,ink),(0,56,48,24,ink),(56,56,24,24,ink),(56,0,24,24,accent)])

def placed_mark(x,y,size,ink=INK,accent=CLAY):
    return f'<g transform="translate({x} {y}) scale({size/80})">{mark(ink,accent)}</g>'

def svg(body,w,h,title='LogiBricks Workspace'):
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}" role="img" aria-label="{html.escape(title)}"><title>{html.escape(title)}</title>{body}</svg>'

def save(name,body,w,h,folder='exports/svg'):
    p=ROOT/folder/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(svg(body,w,h),encoding='utf-8')

def primary(ink=INK,accent=CLAY,descriptor=MUTED):
    a,aw=outline('LogiBricks',44,112,40,650,ink,-0.9)
    b,_=outline('Workspace',20,113,72,450,descriptor,0.7)
    return mark(ink,accent)+a+b, math.ceil(112+aw+2),80

for variant,fg,accent,sub in [('color',INK,CLAY,MUTED),('inverse',PAPER,CLAY,'#D3D2D0'),('black','#000000','#000000','#000000'),('white','#FFFFFF','#FFFFFF','#FFFFFF')]:
    save(f'logibricks-workspace-symbol-{variant}.svg',mark(fg,accent),80,80)
    b,w,h=primary(fg,accent,sub);save(f'logibricks-workspace-primary-{variant}.svg',b,w,h)
    word,ww=outline('LogiBricks',44,0,40,650,fg,-0.9)
    desc,_=outline('Workspace',20,1,72,450,sub,0.7)
    save(f'logibricks-workspace-wordmark-{variant}.svg',word+desc,math.ceil(ww+2),80)
    a,aw=outline('LogiBricks',34,68,37,650,fg,-0.7)
    d,dw=outline('Workspace',25,68+aw+20,36,450,sub,-0.1)
    save(f'logibricks-workspace-inline-{variant}.svg',placed_mark(0,1,48,fg,accent)+a+d,math.ceil(68+aw+20+dw+2),50)
    a,aw=outline('LogiBricks',48,0,212,650,fg,-0.9)
    d,dw=outline('Workspace',22,0,249,450,sub,0.8)
    body=placed_mark(140,20,120,fg,accent)+f'<g transform="translate({(400-aw)/2} 0)">{a}</g>'+f'<g transform="translate({(400-dw)/2} 0)">{d}</g>'
    save(f'logibricks-workspace-stacked-{variant}.svg',body,400,280)

# Editable construction master; wordmark distribution assets above are all paths.
source = mark()+''.join(f'<path d="M{x} -8 V88 M-8 {x} H88" stroke="#18181B" stroke-opacity=".08" stroke-width=".3"/>' for x in range(0,81,8))
save('symbol-construction.svg',f'<g transform="translate(32 32)">{source}</g>',144,144,'source')
save('symbol-editable.svg',mark(),80,80,'source')

# Optical masters: all principal edges sit on integer pixels.
for n,rects in [(16,[(2,2,4,7),(2,10,7,4),(10,10,4,4),(10,2,4,4)]),(20,[(2,2,5,9),(2,13,9,5),(13,13,5,5),(13,2,5,5)])]:
    for variant,fg,ac in [('color',INK,CLAY),('inverse',PAPER,CLAY),('black','#000000','#000000'),('white','#FFFFFF','#FFFFFF')]:
        body=''.join(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="1" fill="{ac if i==3 else fg}"/>' for i,(x,y,w,h) in enumerate(rects))
        save(f'logibricks-workspace-micro-{n}-{variant}.svg',body,n,n)

# Apple source layers: opaque unmasked background plus transparent foregrounds.
for style,bg,fg in [('dark',INK,PAPER),('light',PAPER,INK)]:
    bgbody=f'<rect width="1024" height="1024" fill="{bg}"/>'
    fgbody=placed_mark(224,224,576,fg,CLAY)
    save(f'app-icon-{style}-1024.svg',bgbody+fgbody,1024,1024)
    save(f'background-{style}.svg',bgbody,1024,1024,'exports/platform/apple')
    save(f'framework-{style}.svg',f'<g transform="translate(224 224) scale(7.2)">'+mark(fg,CLAY).split('<rect x="56" y="0"')[0]+'</g>',1024,1024,'exports/platform/apple')
    save('active-module.svg',f'<g transform="translate(224 224) scale(7.2)"><rect x="56" y="0" width="24" height="24" rx="4" fill="{CLAY}"/></g>',1024,1024,'exports/platform/apple')

# Android adaptive icon: 48dp symbol, rounded corners fit the central 66dp circle.
save('adaptive-foreground.svg',placed_mark(30,30,48,PAPER,CLAY),108,108,'exports/platform/android')
save('adaptive-monochrome.svg',placed_mark(30,30,48,'#FFFFFF','#FFFFFF'),108,108,'exports/platform/android')
save('adaptive-background.svg',f'<rect width="108" height="108" fill="{INK}"/>',108,108,'exports/platform/android')

# Presentation board, entirely deterministic vectors and outlined typography.
body=f'<rect width="1600" height="1000" fill="{PAPER}"/>'
def txt(t,sz,x,y,wt=500,col=INK,tracking=0):return outline(t,sz,x,y,wt,col,tracking)[0]
body+=txt('LOGIBRICKS WORKSPACE',18,64,66,600,INK,2)
body+=txt('IDENTITY / 01',14,1330,66,500,MUTED,1)
body+=placed_mark(104,178,184)
body+=txt('LogiBricks',88,350,266,650,INK,-2.4)
body+=txt('Workspace',40,354,331,450,MUTED,1.4)
body+=f'<rect x="1286" y="184" width="190" height="190" rx="43" fill="{INK}"/>'+placed_mark(1332,230,98,PAPER,CLAY)
body+=txt('OPEN WORKBENCH',14,105,414,600,MUTED,2)
body+='<path d="M64 455 H1536" stroke="#DCD6CD"/>'
cards=[(64,490,470,348),(558,490,470,348),(1052,490,484,348)]
for x,y,w,h in cards: body+=f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="20" fill="#FFFFFF"/>'
body+=txt('01 / THE MARK',14,90,532,600,MUTED,1)
body+=placed_mark(214,587,148)
body+=txt('A place for work to come together.',15,112,790,450,MUTED)
body+=txt('02 / ONE COLOR',14,584,532,600,MUTED,1)
body+=placed_mark(612,607,110,'#18181B','#18181B')
body+=f'<rect x="782" y="573" width="204" height="184" rx="16" fill="{INK}"/>'+placed_mark(829,610,110,PAPER,PAPER)
body+=txt('Built to work without color.',15,620,790,450,MUTED)
body+=txt('03 / THE PALETTE',14,1078,532,600,MUTED,1)
for i,(col,label) in enumerate([(INK,'#18181B'),(CLAY,'#D97757'),(PAPER,'#F6F3ED')]):
    xx=1083+i*139
    body+=f'<rect x="{xx}" y="596" width="112" height="94" rx="10" fill="{col}" stroke="#E6E1D8"/>'
    body+=txt(label,15,xx+13,724,550,MUTED)
body+=txt('Graphite / Clay / Warm paper',15,1090,790,450,MUTED)
body+=txt('Modular work. Human direction.',24,66,920,500,INK,-0.4)
body+=txt('DESIGN PROPOSAL  /  04 NOV 2026',13,1200,920,450,MUTED,0.6)
save('identity-overview.svg',body,1600,1000,'guidelines')

# Native SVG UI touchpoint preview; not an implemented application screen.
mock=f'<rect width="1440" height="920" fill="{PAPER}"/>'
mock+=txt('LogiBricks Workspace',38,64,86,600,INK,-0.8)
mock+=txt('Identity in the workspace',18,65,123,450,MUTED)
mock+='<rect x="64" y="168" width="1312" height="660" rx="20" fill="#FFFFFF" stroke="#D9D6D0"/>'
mock+='<path d="M64 215 H1376 M298 215 V828" stroke="#E8E5DF"/>'
mock+=''.join(f'<circle cx="{89+i*18}" cy="192" r="4" fill="#D8D4CC"/>' for i in range(3))
mock+=placed_mark(91,248,32)
mock+=txt('LogiBricks',21,137,271,650,INK,-0.5)+txt('Workspace',12,138,291,450,MUTED,.4)
for i,t in enumerate(['Today','Shipments','My agents','Documents']):
    yy=359+i*53
    if i==0:mock+='<rect x="83" y="329" width="196" height="45" rx="9" fill="#F5E9E3"/>'
    mock+=txt(t,16,105,yy,550 if i==0 else 450,INK if i==0 else MUTED)
mock+=txt('Good morning, Alex.',28,342,275,600,INK,-.5)
mock+=txt('Your team is ready for the next shipment.',16,343,309,450,MUTED)
for i,(title,sub) in enumerate([('Document review','3 items need your attention'),('Quotation draft','Ready for your review'),('Shipment update','New milestone received')]):
    yy=350+i*118
    mock+=f'<rect x="342" y="{yy}" width="650" height="98" rx="14" fill="{PAPER}"/>'
    mock+=f'<rect x="362" y="{yy+20}" width="8" height="58" rx="4" fill="{CLAY if i==0 else "#D8D2C9"}"/>'
    mock+=txt(title,20,390,yy+39,600)+txt(sub,14,390,yy+68,450,MUTED)
mock+=f'<rect x="1031" y="350" width="286" height="334" rx="16" fill="{INK}"/>'
mock+=placed_mark(1118,397,112,PAPER,CLAY)+txt('Your workspace.',22,1060,565,550,PAPER,-.5)+txt('Your team.',22,1060,597,550,PAPER,-.5)
mock+=txt('ILLUSTRATIVE BRAND APPLICATION — NOT A SHIPPED UI',12,64,874,450,MUTED,1)
save('workspace-application.svg',mock,1440,920,'guidelines')

meta={'name':'LogiBricks Workspace','concept':'Open Workbench','version':'1.0-proposal','date':'2026-11-04','palette':{'graphite':INK,'clay':CLAY,'paper':PAPER,'muted':MUTED},'geometry':{'viewBox':[0,0,80,80],'unit':8,'moduleWidth':24,'gap':8,'cornerRadius':4,'clearSpace':24},'font':{'family':'Inter','wordmarkWeight':650,'opticalSize':32,'license':'SIL OFL 1.1','sha256':hashlib.sha256(data).hexdigest(),'source':'https://github.com/google/fonts/tree/main/ofl/inter'},'sourceBrand':'Existing local LogiBricks L-brick mark; primary company colors retained','status':{'vectorMasters':'authored','platformSourceLayers':'prepared','appleIconComposerIntegration':'not validated','androidRuntimeIntegration':'not validated','trademarkClearance':'not performed'},'minimums':{'standardSymbolPx':24,'microSymbolPx':16,'primaryLockupWidthPx':180,'inlineLockupWidthPx':230,'stackedLockupWidthPx':140},'note':'These are proposed identity-use minimums verified in the supplied preview, not universal platform standards.'}
(ROOT/'brand-manifest.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2))
print(json.dumps({'svg_assets':len(list((ROOT/'exports').rglob('*.svg'))),'font_version':TTFont(FONT)['name'].getDebugName(5),'primary_size':primary()[1:]}))
