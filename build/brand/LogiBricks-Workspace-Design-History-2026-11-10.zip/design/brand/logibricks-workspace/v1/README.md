# LogiBricks Workspace 品牌资产 v1

首版设计提案，2026-11-04。主题：**Open Workbench／开放式工作台**。

图形从既有 LogiBricks 的 L 形积木与暖橙强调色演进：三块石墨色模块形成开放结构，右上暖橙模块表示参与工作的能力。名称固定为 **LogiBricks Workspace**，保留大写 L、B、W，不添加 `.AI`。

## 先看这些文件

- `guidelines/identity-overview.png`：准确的设计总览，以此和 SVG 为视觉依据。
- `guidelines/LogiBricks-Workspace-Brand-Guidelines-v1.pdf`：6 页中文使用规范。
- `guidelines/brand-guide.html`：可离线查看的规范源文件，保留目录结构即可。
- `guidelines/brand-application-mockup.png`：imagegen 生成的品牌场景示意，不能从这里裁切 Logo。

## 资产选择

| 用途 | 文件 |
|---|---|
| 常规产品标志 | `exports/svg/logibricks-workspace-primary-color.svg` |
| 深色背景 | `exports/svg/logibricks-workspace-primary-inverse.svg` |
| 紧凑横向位置 | `exports/svg/logibricks-workspace-inline-color.svg` |
| 竖向封面 | `exports/svg/logibricks-workspace-stacked-color.svg` |
| 图形单独使用 | `exports/svg/logibricks-workspace-symbol-color.svg` |
| 单色印刷 | 对应 `black.svg` 或 `white.svg` |
| 16 / 20 px 图形 | 对应 `micro-16` / `micro-20` 光学稿 |
| 浏览器小图标 | `exports/svg/favicon.svg`、`exports/png/logibricks-workspace.ico` |
| Apple 图标源层 | `exports/platform/apple/` |
| Android 图标源层 / XML | `exports/platform/android/` |

`exports/png/` 提供相应透明 PNG。带背景的 app icon、favicon 另行命名；不要把它们与透明主标志混用。SVG 字标已转曲，无外部字体、脚本或嵌入位图。

## 核心规范

- sRGB：Graphite `#18181B`、Clay `#D97757`、Warm paper `#F6F3ED`。
- 图形 80×80 单位；模块宽24、长模块48、间距8、圆角4；安全留白至少24，随图形等比缩放。
- 主组合最小宽180px；单行230px；竖向140px。主图形24px起，16/20px使用光学稿。
- 保持比例和模块关系，禁止旋转、任意换色、添加描边或阴影。照片场景中的真实光影不属于主标志。
- 印刷需依据承印方ICC配置转换和打样；未指定通用CMYK或Pantone。

## 平台交付边界

Apple：提供1024×1024不预裁系统蒙版的深浅图及SVG分层。未生成／验证Icon Composer `.icon`，未接入Xcode工程。

Android：提供108dp分层、monochrome、v26/v33 adaptive-icon与VectorDrawable XML；商店图为512×512、RGBA、sRGB、无外部蒙版／阴影。静态尺寸与安全区已检查，目标App编译与真机遮罩效果仍需集成验收。

未替换现有应用、网站或OpenBot品牌文件。本提案未进行商标近似检索或注册审查。

## 字体与来源

字标基于 Inter Variable 4.001（Google Fonts快照，字体内部版本标记 git-66647c0bb），weight650、opsz32，描述字weight450，已光学调整并转曲。原字体与SIL OFL 1.1位于`source/Inter-variable.ttf`和`licenses/Inter-OFL.txt`。

父品牌参考：本地LogiBricks网站现有L形积木图形及`#18181B`/`#D97757`配色；未改动父品牌文件。应用场景图由imagegen依据本套准确总览生成；主稿本身为可编辑几何SVG。

## 可复现源稿

`source/build_identity.py` 用 fontTools / uharfbuzz 生成母版和转曲字标；`source/render_exports.mjs` 用 sharp 生成PNG和平台层。构建依赖未打入交付包。安装这些依赖后在本目录运行：

```sh
python source/build_identity.py
node source/render_exports.mjs
```

也可用 `--libs <Python依赖目录>` 与 `BRAND_SHARP_MODULE=<sharp模块路径>` 指定隔离依赖。PDF由`brand-guide.html`在Chromium以A4横向、无页眉页脚、保留背景打印。`brand-manifest.json`记录几何、颜色、字体来源和当前验证边界。
